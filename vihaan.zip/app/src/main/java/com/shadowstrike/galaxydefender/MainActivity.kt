package com.shadowstrike.galaxydefender

import android.app.Activity
import android.os.Bundle
import android.view.*
import android.graphics.*
import android.content.Context
import kotlin.random.Random
import kotlin.math.*

class MainActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  window.decorView.systemUiVisibility = 5894 or 1024 or 512 or 4096
  setContentView(GalaxyGame(this))
 }
}
private data class Bullet(var x:Float,var y:Float)
private data class Enemy(var x:Float,var y:Float,var hp:Int,var speed:Float,var radius:Float)
private data class Particle(var x:Float,var y:Float,var vx:Float,var vy:Float,var life:Float)

class GalaxyGame(ctx:Context):View(ctx) {
 private val paint=Paint(3)
 private val bullets= mutableListOf<Bullet>()
 private val enemies= mutableListOf<Enemy>()
 private val particles= mutableListOf<Particle>()
 private val stars=List(90){floatArrayOf(Random.nextFloat(),Random.nextFloat(),Random.nextFloat()*2+1)}
 private var px=0f; private var py=0f; private var score=0; private var lives=3; private var wave=1
 private var active=false; private var over=false; private var left=false; private var right=false; private var firing=false
 private var spawn=0f; private var fire=0f; private var last=System.nanoTime()

 override fun onDraw(c:Canvas) {
  val w=width.toFloat(); val h=height.toFloat()
  if(px==0f){px=w/2;py=h*.80f}
  c.drawColor(Color.rgb(6,10,25))
  stars.forEachIndexed{i,s->paint.color=Color.argb(100+i%150,150,210,255);c.drawCircle(s[0]*w,(s[1]*h+(System.nanoTime()/100000000f*(.1f+s[2]*.05f)))%h,s[2],paint)}
  val dt=min(.033f,(System.nanoTime()-last)/1e9f).toFloat().coerceAtLeast(0f);last=System.nanoTime()
  if(!active){
   center(c,"GALAXY",h*.34f,48f,Color.WHITE);center(c,"DEFENDER",h*.42f,39f,Color.CYAN)
   center(c,"A NATIVE ANDROID ARCADE GAME",h*.50f,14f,Color.LTGRAY)
   button(c,RectF(w*.2f,h*.59f,w*.8f,h*.68f),"TAP TO PLAY")
   center(c,"Touch left/right to move • Hold FIRE to shoot",h*.76f,12f,Color.LTGRAY)
   postInvalidateDelayed(16);return
  }
  if(!over) update(dt,w,h)
  paint.color=Color.CYAN;paint.setShadowLayer(18f,0f,0f,Color.CYAN)
  val ship=Path().apply{moveTo(px,py-25);lineTo(px+20,py+17);lineTo(px,py+9);lineTo(px-20,py+17);close()}
  c.drawPath(ship,paint);paint.clearShadowLayer()
  bullets.forEach{paint.color=Color.WHITE;paint.setShadowLayer(12f,0f,0f,Color.CYAN);c.drawRoundRect(it.x-3,it.y-10,it.x+3,it.y+10,3f,3f,paint);paint.clearShadowLayer()}
  enemies.forEach{e->paint.color=if(e.radius>19)Color.MAGENTA else Color.rgb(255,174,70);paint.setShadowLayer(12f,0f,0f,paint.color);c.drawCircle(e.x,e.y,e.radius,paint);paint.clearShadowLayer()}
  particles.forEach{paint.color=Color.CYAN;paint.alpha=(it.life*400).toInt().coerceIn(0,255);c.drawCircle(it.x,it.y,3f,paint)};paint.alpha=255
  paint.color=Color.WHITE;paint.textSize=17f;paint.typeface=Typeface.DEFAULT_BOLD
  c.drawText("SCORE  $score",18f,30f,paint);c.drawText("WAVE $wave",w-105f,30f,paint)
  paint.color=Color.MAGENTA;c.drawText("♥ ".repeat(lives.coerceAtLeast(0)),18f,55f,paint)
  paint.color=Color.argb(90,65,240,226);c.drawRoundRect(14f,h-75f,w*.34f,h-15f,16f,16f,paint);c.drawRoundRect(w*.68f,h-75f,w-14f,h-15f,16f,16f,paint)
  paint.color=Color.WHITE;paint.textSize=14f;c.drawText("MOVE",w*.12f,h-40f,paint);c.drawText("FIRE",w*.80f,h-40f,paint)
  if(over){paint.color=Color.argb(205,0,0,15);c.drawRect(0f,0f,w,h,paint);center(c,"MISSION FAILED",h*.43f,32f,Color.WHITE);center(c,"SCORE $score",h*.51f,22f,Color.CYAN);button(c,RectF(w*.2f,h*.59f,w*.8f,h*.68f),"PLAY AGAIN")}
  postInvalidateDelayed(16)
 }
 private fun update(dt:Float,w:Float,h:Float){
  if(left)px-=350*dt;if(right)px+=350*dt;px=px.coerceIn(22f,w-22f)
  spawn-=dt;fire-=dt
  if(firing&&fire<=0){bullets.add(Bullet(px,py-25));fire=.19f}
  if(spawn<=0){val r=if(Random.nextFloat()<.2f)22f else 15f;enemies.add(Enemy(Random.nextFloat()*(w-50)+25,-25f,if(r>20)2 else 1,105f+wave*12+Random.nextFloat()*50,r));spawn=max(.3f,1.0f-wave*.06f)}
  bullets.forEach{it.y-=620*dt};bullets.removeAll{it.y < -20}
  enemies.forEach{it.y+=it.speed*dt}
  val dead= mutableSetOf<Enemy>();val used= mutableSetOf<Bullet>()
  enemies.forEach{e->bullets.forEach{b->if(hypot(e.x-b.x,e.y-b.y)<e.radius+7){e.hp--;used.add(b);if(e.hp<=0){dead.add(e);score+=if(e.radius>20)100 else 40;repeat(12){particles.add(Particle(e.x,e.y,Random.nextFloat()*220-110,Random.nextFloat()*220-110,.5f))}}}}}
  enemies.removeAll(dead);bullets.removeAll(used)
  val escaped=enemies.filter{it.y>h-70};if(escaped.isNotEmpty()){enemies.removeAll(escaped.toSet());lives-=escaped.size;if(lives<=0)over=true}
  if(score>=wave*600)wave++
  particles.forEach{it.x+=it.vx*dt;it.y+=it.vy*dt;it.life-=dt};particles.removeAll{it.life<=0}
 }
 private fun center(c:Canvas,t:String,y:Float,size:Float,color:Int){paint.color=color;paint.textSize=size;paint.typeface=Typeface.create("sans-serif-black",1);paint.textAlign=Paint.Align.CENTER;c.drawText(t,width/2f,y,paint);paint.textAlign=Paint.Align.LEFT}
 private fun button(c:Canvas,r:RectF,t:String){paint.color=Color.CYAN;paint.setShadowLayer(15f,0f,0f,Color.CYAN);c.drawRoundRect(r,16f,16f,paint);paint.clearShadowLayer();paint.color=Color.rgb(3,17,30);paint.textSize=18f;paint.typeface=Typeface.DEFAULT_BOLD;paint.textAlign=Paint.Align.CENTER;c.drawText(t,r.centerX(),r.centerY()+6,paint);paint.textAlign=Paint.Align.LEFT}
 override fun onTouchEvent(e:MotionEvent):Boolean{
  val x=e.x;val y=e.y;val w=width.toFloat();val h=height.toFloat()
  when(e.actionMasked){
   MotionEvent.ACTION_DOWN,MotionEvent.ACTION_POINTER_DOWN->{if(!active||over){active=true;over=false;score=0;lives=3;wave=1;bullets.clear();enemies.clear();particles.clear();px=w/2;spawn=.2f;return true};if(y>h-100&&x>w*.65f)firing=true else if(x<w*.5f)left=true else right=true}
   MotionEvent.ACTION_MOVE->{if(y>h-100&&x>w*.65f)firing=true}
   MotionEvent.ACTION_UP,MotionEvent.ACTION_CANCEL,MotionEvent.ACTION_POINTER_UP->{left=false;right=false;firing=false}
  };return true
 }
}
