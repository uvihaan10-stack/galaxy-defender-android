# Galaxy Defender — Native Android Game
Offline native Android arcade shooter with touch controls, waves, score and lives.

## Build APK using GitHub from your phone
1. Create a NEW repository named `galaxy-defender-android`.
2. Upload all files and folders from this ZIP, preserving their paths.
3. Open the repository's Actions tab.
4. Run the `Build Android APK` workflow (or wait for the automatic build).
5. Open the successful workflow run and download the `Galaxy-Defender-APK` artifact.
6. Extract it and install `app-debug.apk` on an Android phone.

This debug APK is for testing and direct sharing, not Play Store release.
